#!/bin/bash

git pull origin master
git submodule update --init
