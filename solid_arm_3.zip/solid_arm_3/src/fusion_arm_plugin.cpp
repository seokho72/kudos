#include <stdio.h>
#include <functional>
#include <iostream>
#include <ros/ros.h>
#include <boost/bind.hpp>
#include <std_msgs/Int32.h>

#include <gazebo/common/common.hh>
#include <gazebo/physics/physics.hh>

#include <cmath>

double PI = 3.141592;

#define D2R  PI/180.
#define R2D  180./PI
#include <ros/console.h>

namespace gazebo {
  class solid_arm_3 : public ModelPlugin{
    physics::LinkPtr link_1;
    physics::LinkPtr link_2;
    physics::LinkPtr link_3;
    physics::LinkPtr link_4;
    physics::LinkPtr link_5;
    physics::LinkPtr link_6;
    physics::LinkPtr base_link;

    physics::JointPtr Joint2;
    physics::JointPtr Joint3;
    physics::JointPtr Joint4;
    physics::JointPtr Joint5;
    physics::JointPtr Joint6;
    physics::JointPtr end_point_joint;

    physics::ModelPtr model;

    //ros topic comm
    ros::NodeHandle nh;
    ros::Subscriber S_move;
    ros::Publisher Pub1;

    common::Time last_update_time;
    event::ConnectionPtr update_connection;
    double dt;
    double time = 0;
    double Joint_curr[6];
    double Joint_error[6]={0.0};
    double Joint_target[6] = {-1.0, -2.1, -1.0, -0.2, 0.8, -0.1};
    double Joint_target_deg[6] = {20, 30, 40, 50, 20, 30};

    common::PID joint_pid[6];
  public:
    void Load(physics::ModelPtr _model, sdf::ElementPtr /*_sdf*/);
    void UpdateAlgorithm(); //1ms
    void topic1_callback(const std_msgs::Int32::ConstPtr& msg){
      ;
    }


  };
  GZ_REGISTER_MODEL_PLUGIN(solid_arm_3);
}

void gazebo::solid_arm_3::Load(physics::ModelPtr _model, sdf::ElementPtr _sdf)
{
  ROS_INFO("solid arm load fuction");

  this->model = _model;

  this->link_1 = this->model->GetLink("link_1");
  this->link_2 = this->model->GetLink("link_2");
  this->link_3 = this->model->GetLink("link_3");
  this->link_4 = this->model->GetLink("link_4");
  this->link_5 = this->model->GetLink("link_5");
  this->link_6 = this->model->GetLink("link_6");
  this->base_link = this->model->GetLink("base_link");

  this->Joint2 = this->model->GetJoint("joint_1");
  this->Joint3 = this->model->GetJoint("joint_2");
  this->Joint4 = this->model->GetJoint("joint_3");
  this->Joint5 = this->model->GetJoint("joint_4");
  this->Joint6 = this->model->GetJoint("joint_5");
  this->end_point_joint = this->model->GetJoint("joint_6");

  //this->joint_pid[0].Init(50,0,10,200,-200,1000,-1000);
  this->joint_pid[0].Init(-20,0,-2);
  this->joint_pid[1].Init(-150,0,-3);
  this->joint_pid[2].Init(-170,0,-4);
  this->joint_pid[3].Init(-10,0,-0.1);
  this->joint_pid[4].Init(-6,0,-0.1);
  this->joint_pid[5].Init(-0.5,0,-0.1);
  this->last_update_time = this->model->GetWorld()->SimTime();
  this->update_connection=event::Events::ConnectWorldUpdateBegin(boost::bind(&solid_arm_3::UpdateAlgorithm,this));


  S_move = nh.subscribe<std_msgs::Int32>("topic1",100, &gazebo::solid_arm_3::topic1_callback, this);
  //Pub1 = nh.advertise()


}

void gazebo::solid_arm_3::UpdateAlgorithm()
{
  common::Time current_time = this->model->GetWorld()->SimTime();
  dt = current_time.Double() - this->last_update_time.Double();
  time = time + dt;

  Joint_curr[0] = this ->Joint2->Position(2);
  Joint_curr[1] = this ->Joint3->Position(2);
  Joint_curr[2] = this ->Joint4->Position(2);
  Joint_curr[3] = this ->Joint5->Position(2);
  Joint_curr[4] = this ->Joint6->Position(2);
  Joint_curr[5] = this ->end_point_joint->Position(2);

  Joint_error[0] = Joint_target[0] - Joint_curr[0];
  Joint_error[1] = Joint_target[1] - Joint_curr[1];
  Joint_error[2] = Joint_target[2] - Joint_curr[2];
  Joint_error[3] = Joint_target[3] - Joint_curr[3];
  Joint_error[4] = Joint_target[4] - Joint_curr[4];
  Joint_error[5] = Joint_target[5] - Joint_curr[5];

  ROS_INFO("Joint0 = %lf", Joint_curr[0]);
  ROS_INFO("Joint1 = %lf", Joint_curr[1]);
  ROS_INFO("Joint2 = %lf", Joint_curr[2]);
  ROS_INFO("Joint3 = %lf", Joint_curr[3]);
  ROS_INFO("Joint4 = %lf", Joint_curr[4]);
  ROS_INFO("Joint5 = %lf", Joint_curr[5]);


  this->joint_pid[0].Update(Joint_error[0],dt);
  this->joint_pid[1].Update(Joint_error[1],dt);
  this->joint_pid[2].Update(Joint_error[2],dt);
  this->joint_pid[3].Update(Joint_error[3],dt);
  this->joint_pid[4].Update(Joint_error[4],dt);
  this->joint_pid[5].Update(Joint_error[5],dt);

  this->Joint2->SetForce(45, this->joint_pid[0].GetCmd());
  this->Joint3->SetForce(45, this->joint_pid[1].GetCmd());
  this->Joint4->SetForce(45, this->joint_pid[2].GetCmd());
  this->Joint5->SetForce(40, this->joint_pid[3].GetCmd());
  this->Joint6->SetForce(40, this->joint_pid[4].GetCmd());
  this->end_point_joint->SetForce(7, this->joint_pid[5].GetCmd());

  this->last_update_time = current_time;
}
